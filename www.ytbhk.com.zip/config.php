<?php
$gl=(isset($_COOKIE['gl']) && $_COOKIE['gl'])?$_COOKIE['gl']:'HK';
define('ROOT_PART', Root_part());
define('APIKEY', 'AIzaSyDq7KxZ9l1qW1I3QPxI-gtnSDxOysMbr9s');
define('GJ_CODE', $gl);
define('SITE_NAME', '海量高清视频 在线观看 视频发布 视频搜索 视频分享');
define('TITLENAME', 'YTBHK');
define('EN2DEKEY', 'du$5^anvb|OVE&y');
define('EMAIL', 'admin@ytbhk.com');
?>