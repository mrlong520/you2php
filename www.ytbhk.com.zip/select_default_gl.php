<?php
/*
@在浏览器选择YOU2PHP缺省国家和地区
2018-7-28
*/
$gls=array(
"HK"=>"香港",
"TW"=>"台湾",
"JP"=>"日本",
"KR"=>"韩国",
"VN"=>"越南",
"IN"=>"印度",
"TH"=>"泰国",
"SG"=>"新加坡",
"PH"=>"菲律宾",
"MY"=>"马来西亚",
"PK"=>"巴基斯坦",
"IL"=>"以色列",
"US"=>"美国",
"CA"=>"加拿大",
"FR"=>"法国",
"UK"=>"英国",
"DE"=>"德国",
"NL"=>"荷兰",
"IT"=>"意大利",
"AU"=>"澳大利亚", 
"UA"=>"乌克兰", 
"RU"=>"俄罗斯");
//可以增加更多的选项

$gl=(isset($_COOKIE['gl']) && $_COOKIE['gl'])?$_COOKIE['gl']:'HK';
if(!isset($gls[$gl])){$gl='HK';}

$select[]="<select id='select_gl'>";
foreach($gls as $k=>$v){
	$is_selected=($k==$gl)?' selected ':'';
	$select[]="  <option value =\"$k\"{$is_selected}>$v</option>";
}
$select[]="</select>";
echo join("\n",$select);
?>

<script>
$(document).ready(function() {
	$("#select_gl").change(function(){
		var gl=$(this).children('option:selected').val()
		document.cookie="gl="+gl;
		window.location.reload()
	})
})
</script>
